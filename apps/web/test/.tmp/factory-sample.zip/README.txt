Budget Travel Printable planner
===============================

DEMO SAMPLE: wording is placeholder content, not written by a live AI model.

What is inside
- 1 cover page
- 1 how-to-use page
- 2 year-at-a-glance pages
- 12 monthly pages
- 26 weekly planner pages
- 3 goals and reflection pages
- 3 notes pages

Files
- budget-travel-printable-planner-a4.pdf
- budget-travel-printable-planner-us-letter.pdf
- README.txt

How to print
- Open the PDF that matches your paper: A4 or US Letter.
- Print at 100% (Actual size). Do not choose "Fit to page".
- Print only the pages you need, and reprint any page again.

Personal use only. Do not resell or share the files.
